/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_289(unsigned x)
{
    return x + 2425393240U;
}

unsigned getval_348()
{
    return 3955448017U;
}

unsigned addval_124(unsigned x)
{
    return x + 3347663031U;
}

void setval_248(unsigned *p)
{
    *p = 2425376806U;
}

void setval_374(unsigned *p)
{
    *p = 2445773128U;
}

unsigned addval_215(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_322()
{
    return 2462550344U;
}

unsigned addval_429(unsigned x)
{
    return x + 2488799645U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_161(unsigned *p)
{
    *p = 2430634440U;
}

void setval_326(unsigned *p)
{
    *p = 3674784395U;
}

unsigned addval_227(unsigned x)
{
    return x + 3234123401U;
}

unsigned addval_418(unsigned x)
{
    return x + 3223372425U;
}

unsigned getval_145()
{
    return 3385118345U;
}

unsigned addval_390(unsigned x)
{
    return x + 2464188744U;
}

void setval_235(unsigned *p)
{
    *p = 3380924813U;
}

void setval_254(unsigned *p)
{
    *p = 3224945288U;
}

void setval_279(unsigned *p)
{
    *p = 3222851209U;
}

unsigned addval_313(unsigned x)
{
    return x + 2497743176U;
}

unsigned getval_444()
{
    return 2425409161U;
}

void setval_479(unsigned *p)
{
    *p = 3286272328U;
}

void setval_120(unsigned *p)
{
    *p = 3526939081U;
}

void setval_305(unsigned *p)
{
    *p = 2429452552U;
}

unsigned addval_273(unsigned x)
{
    return x + 3281178249U;
}

void setval_380(unsigned *p)
{
    *p = 2447411528U;
}

void setval_236(unsigned *p)
{
    *p = 3767091415U;
}

unsigned getval_162()
{
    return 2429659457U;
}

unsigned addval_434(unsigned x)
{
    return x + 3264266889U;
}

void setval_123(unsigned *p)
{
    *p = 3676361097U;
}

unsigned getval_360()
{
    return 3281179017U;
}

unsigned addval_239(unsigned x)
{
    return x + 2425668233U;
}

unsigned getval_301()
{
    return 3375944089U;
}

unsigned addval_312(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_181()
{
    return 2579615369U;
}

unsigned getval_308()
{
    return 3525362312U;
}

unsigned addval_179(unsigned x)
{
    return x + 3676361097U;
}

unsigned getval_419()
{
    return 3531918985U;
}

unsigned addval_339(unsigned x)
{
    return x + 3375940233U;
}

void setval_112(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_251()
{
    return 3531919752U;
}

void setval_318(unsigned *p)
{
    *p = 2495777125U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
